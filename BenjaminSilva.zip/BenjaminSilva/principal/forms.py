from django import forms
from principal.models import Proyecto

class PrincipalProyecto(forms.ModelForm):
    class Meta:
        model = Proyecto
        fields = '__all__'